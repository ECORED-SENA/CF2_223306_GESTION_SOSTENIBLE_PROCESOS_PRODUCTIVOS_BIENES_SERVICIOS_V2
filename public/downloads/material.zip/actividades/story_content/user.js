function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6BgEjc54tPj":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

